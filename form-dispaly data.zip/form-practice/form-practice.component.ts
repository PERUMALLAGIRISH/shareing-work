import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-form-practice",
  templateUrl: "./form-practice.component.html",
  styleUrls: ["./form-practice.component.css"]
})
export class FormPracticeComponent implements OnInit {
  constructor(private http: HttpClient, private formBuilder: FormBuilder) {}
  userForm: FormGroup;
  submitted = false;
  ngOnInit() {
    this.userForm = this.formBuilder.group({
      createdOn: ["", [Validators.required]],
      name: ["", [Validators.required]],
      mrn: ["", [Validators.required]],
      dob: ["", [Validators.required]],
      age: ["", [Validators.required]],
      idNo: ["", [Validators.required]],
      gender: ["", [Validators.required]],
      smh: ["", [Validators.required]],
      nil: ["", [Validators.required]],
      hypertension: ["", [Validators.required]],
      diabetes: ["", [Validators.required]],
      highCholesterol: ["", [Validators.required]],
      smoking: ["", [Validators.required]],
      stroke: ["", [Validators.required]],
      chronicKidneyDisease: ["", [Validators.required]],
      familyHistoryOfCAD: ["", [Validators.required]],
      psh: ["", [Validators.required]],
      angioplasty: ["", [Validators.required]],
      bypassSurgery: ["", [Validators.required]],
      valveSurgery: ["", [Validators.required]],
      aorticSurgery: ["", [Validators.required]],
      congenitalHeartSurgery: ["", [Validators.required]],
      pacemakerImplantation: ["", [Validators.required]],
      aICDImplantation: ["", [Validators.required]],
      otherSpecify: ["", [Validators.required]],
      durgAliergies: ["", [Validators.required]],
      amoxicillin: ["", [Validators.required]],
      penicillin: ["", [Validators.required]]
    });
  }
  // convenience getter for easy access to form fields
  get f() {
    return this.userForm.controls;
  }
  onFormSubmit() {
    this.submitted = true;
    console.log(this.userForm.value);
    this.http
      .post("http://209.105.231.143:900/sign_up", this.userForm.value)
      .subscribe((res: Response) => {
        console.log(res, "Sucessfully Submited!.");
      });
  }
}
