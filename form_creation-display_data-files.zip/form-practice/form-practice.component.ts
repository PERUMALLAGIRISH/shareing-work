import { Component, OnInit } from "@angular/core";

@Component({
  selector: "app-form-practice",
  templateUrl: "./form-practice.component.html",
  styleUrls: ["./form-practice.component.css"]
})
export class FormPracticeComponent implements OnInit {
  constructor() {}

  ngOnInit() {}
}
