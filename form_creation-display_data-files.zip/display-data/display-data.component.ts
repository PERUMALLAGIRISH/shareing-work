import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Component({
  selector: "app-display-data",
  templateUrl: "./display-data.component.html",
  styleUrls: ["./display-data.component.css"]
})
export class DisplayDataComponent implements OnInit {
  result;
  _urlLink = "";

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.http.get(this._urlLink).subscribe(data => {
      //console.log(data);
      data = this.result;
    });
  }
}
